﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day_23
{
    class Calc
    {
        public void add(int a,int b)
        {
            Console.WriteLine("SUM of {0} & {1} = {2} ",a,b,a+b  );
        }
        public void add(int a, int b,int c)
        {
            Console.WriteLine("SUM of {0} + {1} + {2} = {3} ", a, b,c, a + b+c);
        }
        public void add(float a, float b, float c)
        {
            Console.WriteLine("SUM of {0} + {1} + {2} = {3} ", a, b, c, a + b + c);
        }
    }
    class Overloading1
    {
        public static void Main(string[] args)
        {
            Calc ob = new Calc();
            ob.add(22, 33);
            ob.add(22, 3, 4);
            ob.add(2.3f, 5, 6.8f);
        }
    }
}
