﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day_23
{
    class Subtract
    {
        public int sub(int a, int b)
        {
            return (a - b);
        }
        
        public double sub(double a, double b)
        {
            Console.WriteLine("DOUBLE both");
            double c = a - b;
            return c;
        }
        public double sub(int x, double y)
        {
            Console.WriteLine("int DOUBLE ");

            double c = x - y;
            return c;
        }
    }
    class Overloading2
    {
        public static void Main(string[] args)
        {
            Subtract ob = new Subtract();
            int res = ob.sub(22,3);
            Console.WriteLine("SUB = " + res);
            Console.WriteLine("SUB = " + ob.sub(5.8,6));
            Console.WriteLine("SUB = " + ob.sub(5, 6.8));
        }
    }
}
