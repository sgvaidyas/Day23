﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day_23
{
    class Aggregate
    {
        public static void Main(string[] args)
        {
            AggregateExample ob = new AggregateExample();
            ob.calculate();
            ob.display();
        }
    }
}
