﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day_23
{
    class Bank
    {
        public int Accno;
        public string IFSC, bankName,branchName,accountType;
        public Bank()
        {
            Console.WriteLine("ENTER ACCOUNT NUMBER ");
            Accno = int.Parse(Console.ReadLine());
            Console.WriteLine("ENTER IFSC CODE ");
            IFSC = Console.ReadLine();
            Console.WriteLine("ENTER BANK NAME ");
            bankName = Console.ReadLine();
            Console.WriteLine("ENTER BRANCH NAME ");
            branchName = Console.ReadLine();
            Console.WriteLine("ENTER ACCOUNT TYPE ");
            accountType  = Console.ReadLine();
        }

    }

    class Customer : Bank
    {
        string custName, custAddress,adharNumber;
        long phone;
        public Customer()
        {
            Console.WriteLine("ENTER CUSTOMER NAME ");
            custName = Console.ReadLine();
            Console.WriteLine("ENTER CUSTOMER ADDRESS ");
            custAddress = Console.ReadLine();
            Console.WriteLine("ENTER CUSTOMER ADHAR NUMEBR ");
            adharNumber = Console.ReadLine();
            Console.WriteLine("ENTER CUSTOMER PHONE ");
            phone = Convert.ToInt64(Console.ReadLine());

        }
    }

    class Bank_Single
    {
        static void Main(string[] args)
        {
            Customer ob = new Customer();
        }
    }
}
