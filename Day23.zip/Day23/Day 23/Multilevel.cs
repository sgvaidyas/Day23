﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day_23
{


    class Student
    {
        public string name;
        public int roll, classno;
        public char section;
        public void getdetails()
        {
            Console.WriteLine("ENTER NAME  = ");
            name = Console.ReadLine();
            Console.WriteLine("ENTER ROLL  = ");
            roll = int.Parse(Console.ReadLine());
            Console.WriteLine("ENTER CLASS = ");
            classno = int.Parse(Console.ReadLine());
            Console.WriteLine("ENTER SEC   = ");
            section = Console.ReadLine()[0];
        }
        public void display()
        {
            Console.WriteLine("NAME         " + name);
            Console.WriteLine("ROLL NO      " + roll);
            Console.WriteLine("CLASS        " + classno);
            Console.WriteLine("SECTION      " + section);
        }
    }

    class Course : Student
    {
        string cname, code;
        float dur, fees;
        public void getdetails()
        {
            base.getdetails();
            Console.WriteLine("ENTER COURSE NAME  = ");
            cname = Console.ReadLine();
            Console.WriteLine("ENTER CODE  = ");
            code = Console.ReadLine();
            Console.WriteLine("ENTER DURATION = ");
            dur = float.Parse(Console.ReadLine());
            Console.WriteLine("ENTER FEES   = ");
            fees = float.Parse(Console.ReadLine());
        }
        public void display()
        {
            base.display();
            Console.WriteLine("COURSE NAME  " + cname);
            Console.WriteLine("COURSE CODE  " + code);
            Console.WriteLine("COURSE DURATION  " + dur);
            Console.WriteLine("COURSE FEES   " + fees);
        }
    }
    class Report : Course
    {
        public int rank;
        public int[] marks;
        public void getdetails()
        {
            base.getdetails();
            Console.WriteLine("Enter no of subjects " );
            int n = int.Parse(Console.ReadLine());
            int total = 0;
            marks = new int[n];
            for(int i=0;i<n;i++)
            {
                marks[i] = int.Parse(Console.ReadLine());
                total += marks[i];
            }
            float avg = (float)total / n;
            rank = (avg > 70) ? 1 : (avg > 50) ? 2 : (avg >= 35) ? 3 : 4;
        }
        public void display()
        {
            base.display();
            Console.WriteLine("MARKS         ");
            for (int i = 0; i < marks.Length; i++)
                Console.WriteLine("MARKS {0} = {1}" , i+1,marks[i]);
            Console.WriteLine("THE RANK      = "+rank);

        }
    }

    class Multilevel
    {

        static void Main(string[] args)
        {
            Report ob = new Report();
            ob.getdetails();
            ob.display();

        }
    }
}
