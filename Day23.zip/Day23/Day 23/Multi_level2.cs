﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day_23
{
    class A
    {
        public int a;
        public A(int x)
        {
            a = x;
            Console.WriteLine("IN A CLASS val of a = "+ a);
        }
        ~A()
        {
            Console.WriteLine("DESTROYING A");
        }
    }
    class B: A
    {
        public int b;
        public B(int y,int x):base(x)
        {
            b = y;
            Console.WriteLine("IN B CLASS val of b = "+b);
        }
        ~B()
        {
            Console.WriteLine("DESTROYING B");
        }
    }
    
    class C : B
    {
        public int c;
        public C(int x,int y,int z):base(y,z)
        {
            c = x;
            Console.WriteLine("IN C CLASS val of c = "+ c);
        }
        ~C()
        {
            Console.WriteLine("DESTROYING C");
        }
    }
    class Multi_level2
    {
        public static void Main(string[] args)
        {
            C ob = new C(6,7,8);
        }
    }
}
