﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day_23
{
    class StudentInfo
    {
        public int id, age;
        public string name;

        public void getdata()
        {
            Console.WriteLine("ENTER ID  = ");
            id = int.Parse(Console.ReadLine());
            Console.WriteLine("ENTER NAME  = ");
            name = Console.ReadLine();
            Console.WriteLine("ENTER AGE  = ");
            age = int.Parse(Console.ReadLine());
        }
        public void display()
        {
            Console.WriteLine("ID            = "+id);
            Console.WriteLine("NAME          = " + name);
            Console.WriteLine("AGE           = " + age);
        }
    }
    class AggregateExample
    {
        public StudentInfo ob;
        public float  total, avg;
        public int[] marks;
        public string grade;
        public AggregateExample()
        {
            ob = new StudentInfo();
            ob.getdata();
            Console.WriteLine("Enter no of subjects");
            int n = int.Parse(Console.ReadLine());
            marks = new int[n];
            total = 0;
            Console.WriteLine("Enter the marks of each subject");
            for(int i=0;i<n;i++)
            {
                Console.Write("Enter SUB {0} Marks",i+1);
                marks[i] = int.Parse(Console.ReadLine());
                total += marks[i];
            }
        }
        public void calculate()
        {
            avg = total / marks.Length;
            grade = (avg > 70) ? "DISTINCTION" : (avg > 50) ? "FIRST" : (avg > 35) ? "PASS" : (avg > 0 && avg <= 35) ? "FAIL" : "INVALID";            
        }
        public void display()
        {
            Console.WriteLine("\n\n\n");
            ob.display();
            Console.WriteLine("MARKS______________");
            for(int i=0;i<marks.Length;i++)
                Console.WriteLine("MARKS {0} = {1}",i+1,marks[i]);
            Console.WriteLine("TOTAL            = " + total);
            Console.WriteLine("AVERAGE          = " + avg);
            Console.WriteLine("GRADE            = " + grade);
        }
    }
}
