﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day_23
{
    class EnumerationClass
    {
        public enum Days { Mon,Tue,Wed,Thu=80,Fri,Sat,Sun};

        public static void Main(string[] args)
        {
            int x = (int) Days.Mon;
            Console.WriteLine("Monday enumerated value = "+x);
            x = (int)Days.Fri;
            Console.WriteLine("Friday enumerated value = " + x);
            //print days
            foreach(string Day in Enum.GetNames(typeof(Days)))
            {
                Console.WriteLine(Day);
            }

            foreach(int i in Enum.GetValues(typeof(Days)))
            {
                Console.WriteLine(i);
            }

            foreach(var ob in Enum.GetValues(typeof(Days)))
            {
                Console.WriteLine(" {0}  {1} ",(int)ob , (Days)(ob));
            }
        }
    }
}
