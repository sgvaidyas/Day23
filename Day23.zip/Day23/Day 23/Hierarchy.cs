﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day_23
{
    class Shape
    {
        public int len, bred, rad;
        public Shape()
        {
            len = 0;
            bred = 0;
            rad = 0;
        }
        public void getlen()
        {
            Console.WriteLine("Enter the length = ");
            len = int.Parse(Console.ReadLine());
        }
        public void getbred()
        {
            Console.WriteLine("Enter the breadth = ");
            bred = int.Parse(Console.ReadLine());
        }
        public void getrad()
        {
            Console.WriteLine("Enter the radius = ");
            rad = int.Parse(Console.ReadLine());
        }
    }

    class Square : Shape
    {
        public void area()
        {
            Console.WriteLine("Area = " + (len*len));
        }
        public void peri()
        {
            Console.WriteLine("Perimeter = " + 4*(len));
        }

    }
    class Rectangle : Shape
    {
        public void area()
        {
            getlen();
            getbred();
            Console.WriteLine("Area = " + (len * bred));
        }
        public void peri()
        {
            Console.WriteLine("Perimeter = " + 2 * (len+bred));
        }

    }
    class Circle : Shape
    {
        public float pi;
        public Circle()
        {
            pi = 3.142f;
        }
        public void area()
        {
            Console.WriteLine("Area = " + pi *(rad*rad));
        }
        public void circumference()
        {
            Console.WriteLine("Perimeter = " + 2 * (pi*rad));
        }

    }
    class Hierarchy
    {
        public static void Main(string[] args)
        {
            Square sq = new Square();
            sq.getlen();
            sq.area();
            sq.peri();

            Rectangle rec = new Rectangle();
            rec.area();
            rec.peri();

            Circle c = new Circle();
            c.getrad();
            c.area();
            c.circumference();
        }
    }
}
